﻿CREATE TABLE [dbo].[Patients]
(
	[Id] INT NOT NULL PRIMARY KEY  IDENTITY, 
    [Lastname] NVARCHAR(50) NOT NULL,

)
